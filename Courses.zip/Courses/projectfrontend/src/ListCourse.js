    import React, { Component } from 'react';
    import CourseService from './CourseService';
    
    class ListCourse extends Component {
        constructor()
        {
            super();
            this.state={
                courses:[]
            }
        }

        componentDidMount()
        {
            CourseService.getCourses().then((res)=>
            {
                this.setState({courses: res.data});
            }
            );
        }


        render() {
            return (
                <div>
                    <h2 className="text-center"> Courses List </h2>
                    <div className="row">
                        <table className="table table-striped table-bordered">
                            <tbody>
                                <tr>
                                   
                                    <th>Course Title</th>
                                    <th>Course Description</th>
                                    <th>Course Duration</th>
                                    <th>Course Price</th>
                                </tr>
                            </tbody>
                            <tbody>
                                {
                                    this.state.courses.map(
                                        courses=>
                                        <tr key={courses.id}>
                                            <td>{courses.courseTitle}</td>
                                            <td>{courses.courseDescription}</td>
                                            <td>{courses.courseDuration}</td>
                                            <td>{courses.coursePrice}</td>

                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                                        </div>
                </div>
            );
        }
    }
    
    export default ListCourse;
    