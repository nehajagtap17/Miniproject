import logo from './logo.svg';
import './App.css';
import ListCourse from './ListCourse';

function App() {
  return (
    <ListCourse />
  );
}

export default App;
